import 'package:flutter/material.dart';

void main() {
  runApp(FlutterApp());
}

class FlutterApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        appBar: AppBar(
          title: Center(child: Text("LabWork")),
          backgroundColor: Color(0xFFD9D9D9),
          bottom: TabBar(
            tabs: [
              Tab(text: "Self"),
              Tab(text: "DIU"),
              Tab(text: "My"),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            SelfPage(),
            DIUPage(),
            MyPage(),
          ],
        ),
      ),
    );
  }
}

class SelfPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 86,
            backgroundImage: AssetImage("assets/image/download.jpg"),
          ),
          SizedBox(height: 20),
          Text("Name: Takey Yeasir Sajin", style: TextStyle(fontSize: 16)),
          Text("Student ID: 221-15-4938", style: TextStyle(fontSize: 16)),
          Text("Department of CSE, Daffodil International University",
              textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
        ],
      ),
    );
  }
}

class DIUPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset("assets/image/download.jpg"),
          SizedBox(height: 20),
          Text("Daffodil Smart City (DSC), Birulia, Savar, Dhaka-1216",
              textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {},
            child: Text("Visit Website"),
          ),
        ],
      ),
    );
  }
}

class MyPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset("assets/image/download.jpg"),
          SizedBox(height: 20),
          Text("Regional 1st Runner-up (Dhaka)\nNASA Space Apps Challenge 2024",
              textAlign: TextAlign.center, style: TextStyle(fontSize: 16)),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {},
            child: Text("Details"),
          ),
          SizedBox(height: 30),
          Image.asset("assets/image/download.jpg"),
          SizedBox(height: 20),
          Text(
              "Champion (Project)\nBig Data, IoT & Machine Learning Conference 2023",
              textAlign: TextAlign.center,
              style: TextStyle(fontSize: 16)),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {},
            child: Text("Details"),
          ),
        ],
      ),
    );
  }
}
